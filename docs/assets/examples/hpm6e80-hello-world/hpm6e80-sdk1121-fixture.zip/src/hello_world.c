/* HPM6E80 real-target waveform, RTT and FreeRTOS/SystemView fixture. */
#include <stdio.h>
#include <math.h>
#include "board.h"
#include "hpm_l1c_drv.h"
#include "FreeRTOS.h"
#include "task.h"
#include "SEGGER_RTT.h"
#include "SEGGER_SYSVIEW.h"
#include "hpm_clock_drv.h"
extern const SEGGER_SYSVIEW_OS_API SYSVIEW_X_OS_TraceAPI;
static void article_system_description(void) {
    SEGGER_SYSVIEW_SendSysDesc("N=HPM6E80 MKLink demo,O=FreeRTOS,D=HPM6E80");
    SEGGER_SYSVIEW_SendSysDesc("I#4007=MTimer,I#4003=Software,I#4011=ECall");
}
volatile unsigned article_build_id = 0x20260919;
volatile unsigned boot_stage;
volatile unsigned assert_line;
void article_assert(unsigned line) { assert_line=line; taskDISABLE_INTERRUPTS(); for(;;){} }
volatile unsigned wave_tick, telemetry_count, echo_count;
volatile float wave_reference, wave_response, wave_error;
volatile float phase_0, phase_90, phase_180, phase_270;
volatile float response_gain = 0.05f;
volatile unsigned memory_test[1024] __attribute__((aligned(32)));
static void wave_task(void *arg) {
    (void)arg;
    TickType_t last = xTaskGetTickCount();
    for (;;) {
        ++wave_tick;
        wave_reference = 100.0f * sinf((float)(wave_tick % 1000) * 0.0062831853f);
        phase_0 = wave_reference;
        phase_90 = 100.0f * cosf((float)(wave_tick % 1000) * 0.0062831853f);
        phase_180 = -phase_0;
        phase_270 = -phase_90;
        wave_response += response_gain * (wave_reference - wave_response);
        wave_error = wave_reference - wave_response;
        vTaskDelayUntil(&last, pdMS_TO_TICKS(1));
    }
}
static void telemetry_task(void *arg) {
    (void)arg;
    char line[128];
    for (;;) {
        int n = snprintf(line, sizeof(line), "HPM6E80 build=%08x tick=%u telemetry=%u echo=%u\n", article_build_id, wave_tick, ++telemetry_count, echo_count);
        SEGGER_RTT_Write(0, line, n);
        vTaskDelay(pdMS_TO_TICKS(500));
    }
}
static void echo_task(void *arg) {
    (void)arg;
    char b[128];
    for (;;) {
        unsigned n=SEGGER_RTT_Read(0,b,sizeof(b));
        if(n) { echo_count += n; SEGGER_RTT_WriteString(0,"echo: "); SEGGER_RTT_Write(0,b,n); }
        vTaskDelay(pdMS_TO_TICKS(10));
    }
}
int main(void) {
    board_init();
    /* Keep debugger/RTT accesses coherent in this measurement fixture. */
    l1c_dc_flush_all();
    l1c_dc_disable();
    for(unsigned i=0;i<1024;i++) memory_test[i]=0xA5000000u ^ (i*0x10203u);
    boot_stage=1;
    SEGGER_RTT_Init();
    boot_stage=2;
    /* SDK default configuration has no OS callback. Supply the FreeRTOS
     * task-list callback so a host attaching later receives task names. */
    unsigned core_hz = clock_get_core_clock_ticks_per_ms() * 1000U;
    SEGGER_SYSVIEW_Init(core_hz, core_hz, &SYSVIEW_X_OS_TraceAPI, article_system_description);
    SEGGER_SYSVIEW_SetRAMBase(0x01200000U);
    boot_stage=3;
    if(xTaskCreate(wave_task,"Wave1kHz",512,NULL,3,NULL)!=pdPASS ||
       xTaskCreate(telemetry_task,"Telemetry",512,NULL,1,NULL)!=pdPASS ||
       xTaskCreate(echo_task,"RttEcho",512,NULL,2,NULL)!=pdPASS) for(;;){}
    boot_stage=4;
    vTaskStartScheduler();
    boot_stage=5;
    for(;;){}
}


volatile unsigned trap_cause, trap_pc, trap_value;
void freertos_risc_v_application_exception_handler(void) {
    __asm volatile("csrr %0, mcause" : "=r"(trap_cause));
    __asm volatile("csrr %0, mepc" : "=r"(trap_pc));
    __asm volatile("csrr %0, mtval" : "=r"(trap_value));
    for (;;) {}
}
