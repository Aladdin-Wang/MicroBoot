# HPM5301 hello_world documentation fixtures

Base SDK: HPM SDK 1.11.0; board: hpm5301evklite; type: flash_xip; debug configuration.

The default variant uses src/hello_world.c (16 sine channels). HPM_DOC_RTT=ON enables RTT build13. HPM_DOC_RTOS=ON selects src/rtos/main.c, build14.
For RTOS, copy middleware/segger_sysview from an installed HPM SDK1.12.1 to third_party/segger_sysview, preserving all upstream license and copyright files. This archive does not redistribute that dependency. FreeRTOS and RTT are supplied by the base SDK1.11.0.

Build each variant in a separate directory. Use the matching BIN and ELF; symbol addresses differ. Flash HPM5301xEGx through HPM ROM API at 0x80000400, board hpm5301evklite. The documentation performance baseline uses baseline/src/hello_world.c with baseline/CMakeLists.txt, build12; use those two files together in a separate copy of the SDK example.

The optional src/rtos/trap_demo.c.txt is the build15 source used for deliberate illegal-instruction testing. It is not compiled by default. Its second exception callback argument is the FreeRTOS-adjusted return PC (fault PC +4), not raw mepc. Both unlock keys are needed to trigger. Restore normal build14 afterward.
